# Cryptographic Trapdoor Arsenal V3.2 — 10 Separated Locks & Composable Cascade Engine

This repository contains both the original 4-layer cryptographic challenge (`variant5.py`, `variant6.py`, `variant7.py`, `variant9.py`) and the newly architected **10-Lock Orthogonal Trapdoor Arsenal** (`trapdoors.md`, `TRAPDOOR_ARSENAL_V3.md`, `locks_A.py`, `locks_B.py`, `cascade_engine.py`, `verify_locks.py`, and `main.py`).

---

## 1. Repository File Architecture

| File | Role & Contents |
| :--- | :--- |
| `trapdoors.md` | **Formal Mathematical Framework**: Complete 6-module structure (Academic Source, Math Principles, Public Surface, AI Defeat Logic, Solver Path, Implementation Spec) for all 10 separated trapdoor locks plus the universal cascade specification. |
| `TRAPDOOR_ARSENAL_V3.md` | Chinese technical specification & anti-LLM defense architecture report for Locks 01–10. |
| `locks_A.py` | Pure-Python implementations (`generate` & `solve`) for **Locks 01 to 05** (Cyclotomic Torus $\mathbb{T}_6$, Gaussian Rédei $\Phi_4$, Octic Torus $\Phi_8$, $\Delta_K=-7$ CM Curve, Genus-2 Hyperelliptic Cantor Jacobian). |
| `locks_B.py` | Pure-Python implementations (`generate` & `solve`) for **Locks 06 to 10** (12D Quaternion Algebra $\mathbb{H}_{-1,-1}(R_3)$, Prime-Order $\mathrm{SL}_3$ Cubic Lucas, 4D+4D Dyadic Coppersmith Cascade, Chebyshev/Lucas-$V$ SETUP, Dodecic Torus $\mathbb{T}_{12}$). |
| `cascade_engine.py` | Unified `LOCK_REGISTRY`, standalone runner (`generate_single_lock`, `solve_single_lock`), and multi-layer Matryoshka cascade builder/solver (`build_cascade`, `solve_cascade`). |
| `main.py` | Interactive Web Dashboard server on `0.0.0.0:3000` (with REST endpoints `/`, `/health`, `/api/locks`, `/api/test-lock`, `/api/test-cascade`, `/api/report`) and CLI dispatcher. |
| `verify_locks.py` | Dedicated CLI verification & benchmark runner for testing individual locks, custom lock cascades, or the full 10-lock suite. |
| `CHANGELOG.md` | Detailed chronological audit log of all architectural additions, mathematical proofs, bug fixes, and file updates. |
| `ctflib.py` | Self-contained pure-Python cryptographic & algebraic number theory library (Kronecker polynomial multiplication, Newton division, subproduct/remainder tree `batch_poly_gcd`, integer LLL `lll`, ECM/Pollard utilities). |
| `package.json` & `metadata.json` | Container supervisor startup (`npm run dev` / `npm run build`) and AI Studio applet metadata. |
| `variant5.py`, `variant6.py`, `variant7.py`, `variant9.py` | Original repository variants (preserved unmodified for backward compatibility). |

---

## 2. Summary of the 10 Separated Locks (100% Orthogonal to Variants 5, 6, 7, 9)

Every lock exposes **only** a clean RSA tuple `(N, e, c)` on the public surface—zero auxiliary curve coefficients, zero matrix parameters, and zero bit-prefix hints.

1. **Lock 01 (`lock01`)**: $\Phi_6(p) = p^2 - p + 1$ Cyclotomic Ring $\mathbb{Z}_N[\zeta_7]$ Galois-Frobenius Torus $\mathbb{T}_6$ with Self-Referential Cofactor Entanglement $\delta_2 N \equiv \delta_1 \pmod{C_6}$ — **Surface: `(N, e=65537, c)`** (`KeyGen: 0.11s, Solve: 3.11s`).
2. **Lock 02 (`lock02`)**: $\Phi_4(p) = p^2 + 1$ Projective Rédei Rational Conic $\mathbb{P}^1_\Delta(\mathbb{Z}_N[i])$ with $\Delta = 1 + 2i$ and Montgomery Batch Norm Inversion — **Surface: `(N, e, c)`** (`KeyGen: 0.22s, Solve: 2.76s`).
3. **Lock 03 (`lock03`)**: $\Phi_8(p) = p^4 + 1$ Octic Cyclotomic Torus $\mathbb{P}^1_t(R_4)$ over $R_4 = \mathbb{Z}_N[t]/(t^4-2t^2+5)$ with Biquadratic Subfield Adjoint Batch Inversion — **Surface: `(N, e, c)`** (`KeyGen: 0.05s, Solve: 5.24s`).
4. **Lock 04 (`lock04`)**: Discriminant $\Delta_K = -7$ ($j = -3375 \neq 0, 1728$, conductor $f=2$) Quadratic-Twist CM Curve with Factored Self-Referential Scalar $\delta_2(N^2-4) \equiv \delta_1(N+2) \pmod{M_p}$ — **Surface: `(N, e=65537, c)`** (`KeyGen: 0.26s, Solve: 3.74s`).
5. **Lock 05 (`lock05`)**: Genus-2 Hyperelliptic Curve $\mathrm{Jac}(y^2 = x^5 + 8)$ Quartic-CM Supersingular Abelian Surface over $\mathbb{Z}/N\mathbb{Z}$ via Cantor's Mumford Divisor Algorithm — **Surface: `(N, e, c)`** (`KeyGen: 0.10s, Solve: 54.3s`).
6. **Lock 06 (`lock06`)**: 12D Non-Commutative Quaternion Algebra $\mathbb{H}_{-1,-1}(\mathbb{Z}_N[t]/(t^3-2))$ Double Norm Collapse ($\gcd(p^3+1, p^4+p^2+1) = \Phi_6(p)$) & Skolem–Noether Inner Conjugation — **Surface: `(N, e, c)`** (`KeyGen: 0.14s, Solve: 16.7s`).
7. **Lock 07 (`lock07`)**: Prime-Order Companion Matrix Cubic Lucas Group $\mathrm{SL}_3(\mathbb{Z}/N\mathbb{Z})$ where $M_3 = p^2+p+1$ is a **1024-bit PRIME** (0% smoothness) — **Surface: `(N, e, c)`** (`KeyGen: 131s, Solve: 1.47s`).
8. **Lock 08 (`lock08`)**: Two-Stage 4D Cubic Orthogonal Lattice + Base-$2^{240}$ Dyadic-Folded 4D Linear Divisor Coppersmith Cascade (`m=2, t=2`) — **Surface: `(N, e, c)`** (`KeyGen: 0.12s, Solve: 8.57s`).
9. **Lock 09 (`lock09`)**: Symmetric Chebyshev / Lucas-$V$ Product-to-Sum Kleptographic SETUP ($V_{d_1}(7)V_{d_2}(7) \equiv V_{d_1+d_2}(7) + V_{|d_1-d_2|}(7) \pmod{\Phi_6(2^{180})}$) with Modulo Wrap-Around — **Surface: `(N, e=65537, c)`** (`KeyGen: 0.15s, Solve: 0.37s`).
10. **Lock 10 (`lock10`)**: $\Phi_{12}(p) = p^4 - p^2 + 1$ Dodecic Cyclotomic Ring $\mathbb{Z}_N[\zeta_{13}]$ 4-Term Frobenius Torus Projection $\Psi_{12}(\sigma) = \sigma^8 + \sigma^6 - \sigma^2 - 1$ — **Surface: `(N, e, c)`** (`KeyGen: 0.05s, Solve: 6.32s`).

---

## 3. Quick Start & Usage

### Run Web Dashboard on Port 3000
```bash
python3 main.py
```

### Run a Single Lock via CLI
```bash
python3 -u verify_locks.py --lock lock01
python3 -u verify_locks.py --lock lock04
python3 -u verify_locks.py --lock lock08
python3 -u verify_locks.py --lock lock09
```

### Combine Any Locks into a Multi-Layer Matryoshka Cascade
```bash
python3 -u verify_locks.py --cascade lock01,lock04,lock08,lock09
```

### Run the Full 10-Lock Benchmark & Verification Suite
```bash
python3 -u verify_locks.py
```
