"""
locks_A.py — Pluggable Algebraic Trapdoor Locks 01 to 05
========================================================
Each lock implements a uniform pluggable interface:
  - generate(K_bound=..., seed=..., verbose=...) -> (pub_dict, sk_dict)
  - solve(pub_dict, verbose=...)                 -> (p, q)

All 5 locks in this module are 100% distinct from existing Variants 5, 6, 7, 9:
  Lock 01 : Phi_6(p) = p^2 - p + 1 Cyclotomic Ring Z_N[zeta_7] Frobenius Torus T_6
            with Self-Referential Cofactor Entanglement (Public surface: N, e=65537, c)
  Lock 02 : Phi_4(p) = p^2 + 1 Projective Redei Rational Conic over Z_N[i]
            with Dual-Track Exponent Entanglement (Public surface: N, e, c)
  Lock 03 : Phi_8(p) = p^4 + 1 Octic Cyclotomic Redei Torus P^1(R_4) over Z_N[t]/(t^4-2t^2+5)
            with Quartic Norm Non-Residue (Public surface: N, e, c)
  Lock 04 : Discriminant D = -7 (j = -3375 != 0, 1728) Conductor f=2 CM Curve
            with Quadratic-Congruence Frobenius Entanglement (Public surface: N, e=65537, c)
  Lock 05 : Genus-2 Quartic-CM Hyperelliptic Jacobian Jac(y^2 = x^5 + a) over Z/NZ
            via Cantor's Mumford Divisor Algorithm (Public surface: N, e, c)
"""
import math, random, time
from ctflib import (
    is_prime, primes_upto, sqrt_mod, inv_mod_n, FactorFound,
    batch_poly_gcd, ec_add, ec_mul
)


def _batch_inv_mod_n(vals, n):
    """Montgomery batch inversion modulo N (1 inversion + 3(k-1) muls).
    If any element shares a non-trivial factor with N, raises FactorFound(g).
    """
    if not vals:
        return []
    pref = [vals[0] % n]
    for v in vals[1:]:
        pref.append(pref[-1] * (v % n) % n)
    g = math.gcd(pref[-1], n)
    if g != 1:
        if 1 < g < n:
            raise FactorFound(g)
        for v in vals:
            gg = math.gcd(v % n, n)
            if 1 < gg < n:
                raise FactorFound(gg)
        raise ZeroDivisionError("batch_inv zero")
    inv_all = pow(pref[-1], -1, n)
    out = [0] * len(vals)
    for i in range(len(vals) - 1, 0, -1):
        out[i] = inv_all * pref[i - 1] % n
        inv_all = inv_all * (vals[i] % n) % n
    out[0] = inv_all
    return out


def _crt_combine(residues, moduli):
    r_all, M_all = 0, 1
    for r, l in zip(residues, moduli):
        g = pow(M_all, -1, l)
        r_all = r_all + M_all * ((r - r_all) * g % l)
        M_all *= l
    return r_all % M_all, M_all


# ======================================================================
# LOCK 01: Phi_6(p) = p^2 - p + 1 Galois-Frobenius Torus T_6 in Z_N[zeta_7]
# ======================================================================

def _a7_canon(v, n):
    c6 = v[6]
    return [(v[i] - c6) % n for i in range(6)]


def _a7_mul(a, b, n):
    res = [0] * 7
    for i, ai in enumerate(a):
        if ai:
            for j, bj in enumerate(b):
                res[(i + j) % 7] += ai * bj
    return [x % n for x in res]


def _a7_pow(base, k, n):
    res = [1, 0, 0, 0, 0, 0, 0]
    b = base[:]
    while k > 0:
        if k & 1:
            res = _a7_mul(res, b, n)
        b = _a7_mul(b, b, n)
        k >>= 1
    return res


def _a7_frob(a, k):
    s = pow(3, k, 7)
    out = [0] * 7
    for i in range(7):
        out[(i * s) % 7] = a[i]
    return out


def _poly_trim(p):
    p = p[:]
    while p and p[-1] == 0:
        p.pop()
    return p


def _poly_divmod_small(A, B, n):
    A = _poly_trim([x % n for x in A])
    B = _poly_trim([x % n for x in B])
    if not B:
        raise ZeroDivisionError
    if len(A) < len(B):
        return [], A
    inv_lc = inv_mod_n(B[-1], n)
    deg_diff = len(A) - len(B)
    Q = [0] * (deg_diff + 1)
    R = A[:]
    for i in range(deg_diff, -1, -1):
        if len(R) == i + len(B):
            coef = R[-1] * inv_lc % n
            Q[i] = coef
            if coef:
                for j in range(len(B)):
                    R[i + j] = (R[i + j] - coef * B[j]) % n
            R.pop()
            R = _poly_trim(R)
    return _poly_trim(Q), R


def _poly_extgcd_inv(a_canon, mod_poly, n):
    old_r, r = [x % n for x in mod_poly], _poly_trim([x % n for x in a_canon])
    old_t, t = [], [1]
    while r:
        q, rem = _poly_divmod_small(old_r, r, n)
        qt = [0] * (len(q) + len(t))
        for i, qi in enumerate(q):
            for j, tj in enumerate(t):
                qt[i + j] = (qt[i + j] + qi * tj) % n
        L = max(len(old_t), len(qt))
        new_t = [((old_t[i] if i < len(old_t) else 0) - (qt[i] if i < len(qt) else 0)) % n
                 for i in range(L)]
        old_r, r = r, rem
        old_t, t = t, _poly_trim(new_t)
    if len(old_r) != 1:
        for c in old_r:
            g = math.gcd(c, n)
            if 1 < g < n:
                raise FactorFound(g)
        raise ZeroDivisionError("poly not invertible")
    inv_c = inv_mod_n(old_r[0], n)
    deg = len(mod_poly) - 1
    return [(old_t[i] * inv_c) % n if i < len(old_t) else 0 for i in range(deg)]


def lock01_generate(K_bound=1 << 11, B=1 << 13, n_small=36, seed=None, verbose=True):
    if seed is not None:
        random.seed(seed)
    t0 = time.time()
    pool = [l for l in primes_upto(B) if l > (1 << 11) and l % 6 == 1 and l != 7]
    M_full = math.prod([l for l in primes_upto(B) if l % 6 == 1])

    while True:
        ls = random.sample(pool, n_small)
        L_smooth = math.prod(ls)
        if not (440 <= L_smooth.bit_length() <= 470):
            continue
        roots = []
        for l in ls:
            s = sqrt_mod(l - 3, l)
            r = (s + 1) * pow(2, -1, l) % l
            roots.append(r)
        r_all, M_all = _crt_combine(roots + [3], ls + [7])
        lo_p = 1 << 503
        k0 = (lo_p - r_all) // M_all
        p = None
        for k in range(k0, k0 + 250000):
            cand = r_all + k * M_all
            if cand.bit_length() == 504 and is_prime(cand):
                p = cand
                break
        if p is None:
            continue
        Phi6 = p * p - p + 1
        G = math.gcd(Phi6, M_full)
        C6 = Phi6 // G
        if C6.bit_length() <= 555 and math.gcd(p, C6) == 1:
            break

    inv_p = pow(p, -1, C6)
    while True:
        d1 = random.randrange(3, K_bound)
        if not is_prime(d1):
            continue
        d2 = random.randrange(3, K_bound)
        if d2 == d1 or not is_prime(d2) or math.gcd(d2, C6) != 1:
            continue
        r_q = inv_p * d1 * pow(d2, -1, C6) % C6
        q = None
        for m in range(2, 4000):
            cand_q = r_q + m * C6
            if cand_q != p and is_prime(cand_q):
                q = cand_q
                break
        if q is not None:
            break

    N = p * q
    assert (d2 * M_full * N - d1 * M_full) % Phi6 == 0
    if verbose:
        print("  [Lock 01 KeyGen] %.2fs | p=%db q=%db N=%db | C6=%db | d1=%d d2=%d" %
              (time.time() - t0, p.bit_length(), q.bit_length(), N.bit_length(),
               C6.bit_length(), d1, d2))
    pub = {"N": N, "e": 65537, "K_bound": K_bound, "B": B}
    sk = {"p": p, "q": q, "d1": d1, "d2": d2, "Phi6": Phi6, "C6": C6}
    return pub, sk


def lock01_solve(pub, verbose=True):
    N = int(pub["N"])
    K_bound = int(pub.get("K_bound", 1 << 11))
    B = int(pub.get("B", 1 << 13))
    t0 = time.time()

    M = math.prod([l for l in primes_upto(B) if l % 6 == 1])
    mod_phi7 = [1, 1, 1, 1, 1, 1, 1]

    try:
        beta = [2, 1, 0, 0, 0, 0, 0]
        num = _a7_mul(_a7_frob(beta, 4), _a7_frob(beta, 3), N)
        den = _a7_mul(_a7_frob(beta, 1), beta, N)
        den_inv_6 = _poly_extgcd_inv(_a7_canon(den, N), mod_phi7, N)
        tau = _a7_mul(num, den_inv_6 + [0], N)

        Q0 = _a7_pow(tau, M, N)
        R0 = _a7_pow(Q0, N, N)

        lhs, cur = [], [1, 0, 0, 0, 0, 0, 0]
        for d2 in range(1, K_bound):
            cur = _a7_mul(cur, R0, N)
            if is_prime(d2):
                lhs.append(_a7_canon(cur, N)[0])

        rhs, cur = [], [1, 0, 0, 0, 0, 0, 0]
        for d1 in range(1, K_bound):
            cur = _a7_mul(cur, Q0, N)
            if is_prime(d1):
                rhs.append(_a7_canon(cur, N)[0])

        g = batch_poly_gcd(lhs, rhs, N)
        if g and 1 < g < N:
            if verbose:
                print("  [Lock 01 Solve]  %.2fs | Phi_6(p) T_6 torus collision hit (%dx%d)" %
                      (time.time() - t0, len(lhs), len(rhs)))
            return g, N // g
    except FactorFound as ff:
        g = math.gcd(ff.p, N)
        if 1 < g < N:
            return g, N // g
    return None


# ======================================================================
# LOCK 02: Phi_4(p) = p^2 + 1 Projective Redei Conic over Z_N[i]
# ======================================================================

def _r2_mul(a, b, n):
    return ((a[0] * b[0] - a[1] * b[1]) % n, (a[0] * b[1] + a[1] * b[0]) % n)


def _r2_add(a, b, n):
    return ((a[0] + b[0]) % n, (a[1] + b[1]) % n)


def _redei2_mul(P, Q, delta, n):
    U1, V1 = P
    U2, V2 = Q
    u1u2 = _r2_mul(U1, U2, n)
    v1v2 = _r2_mul(V1, V2, n)
    dv = _r2_mul(delta, v1v2, n)
    U3 = _r2_add(u1u2, dv, n)
    U1V2 = _r2_mul(U1, V2, n)
    V1U2 = _r2_mul(V1, U2, n)
    V3 = _r2_add(U1V2, V1U2, n)
    return (U3, V3)


def _redei2_pow(P, k, delta, n):
    res = ((1, 0), (0, 0))
    base = P
    while k > 0:
        if k & 1:
            res = _redei2_mul(res, base, delta, n)
        base = _redei2_mul(base, base, delta, n)
        k >>= 1
    return res


def lock02_generate(K_bound=1 << 11, B=1 << 13, n_small=35, seed=None, verbose=True):
    if seed is not None:
        random.seed(seed)
    t0 = time.time()
    pool = [l for l in primes_upto(B) if l > (1 << 11) and l % 4 == 1 and l != 5]
    M_full = math.prod([l for l in primes_upto(B) if l % 4 == 1])

    while True:
        ls = random.sample(pool, n_small)
        L_smooth = math.prod(ls)
        if not (430 <= L_smooth.bit_length() <= 475):
            continue
        roots = [sqrt_mod(l - 1, l) for l in ls]
        r_all, M_all = _crt_combine(roots + [7], ls + [20])
        lo_p = 1 << 511
        k0 = (lo_p - r_all) // M_all
        p = None
        for k in range(k0, k0 + 250000):
            cand = r_all + k * M_all
            if cand.bit_length() == 512 and is_prime(cand):
                p = cand
                break
        if p is None:
            continue
        Phi4 = p * p + 1
        G = math.gcd(Phi4, M_full)
        C4 = Phi4 // G
        if C4.bit_length() >= 540:
            break

    while True:
        q = random.getrandbits(512) | (1 << 511) | 1
        if q != p and is_prime(q):
            break
    N = p * q
    e0 = N % Phi4

    while True:
        d1 = random.randrange(3, K_bound)
        if not is_prime(d1):
            continue
        d2 = random.randrange(3, K_bound)
        if d2 == d1 or not is_prime(d2):
            continue
        if math.gcd(d2 + C4, Phi4) != 1:
            continue
        e = (d1 * e0 + C4) * pow(d2 + C4, -1, Phi4) % Phi4
        if e > 1 and math.gcd(e, (p - 1) * (q - 1)) == 1:
            break

    assert (d2 * M_full * e - d1 * M_full * N) % Phi4 == 0
    if verbose:
        print("  [Lock 02 KeyGen] %.2fs | p=%db q=%db N=%db | e=%db | d1=%d d2=%d" %
              (time.time() - t0, p.bit_length(), q.bit_length(), N.bit_length(),
               e.bit_length(), d1, d2))
    pub = {"N": N, "e": e, "K_bound": K_bound, "B": B}
    sk = {"p": p, "q": q, "d1": d1, "d2": d2, "Phi4": Phi4, "C4": C4}
    return pub, sk


def lock02_solve(pub, verbose=True):
    N = int(pub["N"])
    e = int(pub["e"])
    K_bound = int(pub.get("K_bound", 1 << 11))
    B = int(pub.get("B", 1 << 13))
    t0 = time.time()

    M = math.prod([l for l in primes_upto(B) if l % 4 == 1])
    delta = (1, 2)
    P0 = ((2, 1), (1, 0))

    try:
        Q_L = _redei2_pow(P0, M * e, delta, N)
        Q_R = _redei2_pow(P0, M * N, delta, N)

        pts_L, cur = [], ((1, 0), (0, 0))
        for d2 in range(1, K_bound):
            cur = _redei2_mul(cur, Q_L, delta, N)
            if is_prime(d2):
                pts_L.append(cur)

        pts_R, cur = [], ((1, 0), (0, 0))
        for d1 in range(1, K_bound):
            cur = _redei2_mul(cur, Q_R, delta, N)
            if is_prime(d1):
                pts_R.append(cur)

        all_pts = pts_L + pts_R
        norms = [(V[0] * V[0] + V[1] * V[1]) % N for (_, V) in all_pts]
        inv_norms = _batch_inv_mod_n(norms, N)

        scalars = []
        for ((u0, u1), (v0, v1)), inv_nm in zip(all_pts, inv_norms):
            scalars.append((u0 * v0 + u1 * v1) % N * inv_nm % N)

        kL = len(pts_L)
        lhs, rhs = scalars[:kL], scalars[kL:]
        g = batch_poly_gcd(lhs, rhs, N)
        if g and 1 < g < N:
            if verbose:
                print("  [Lock 02 Solve]  %.2fs | Phi_4(p) Redei conic collision hit (%dx%d)" %
                      (time.time() - t0, len(lhs), len(rhs)))
            return g, N // g
    except FactorFound as ff:
        g = math.gcd(ff.p, N)
        if 1 < g < N:
            return g, N // g
    return None


# ======================================================================
# LOCK 03: Phi_8(p) = p^4 + 1 Octic Cyclotomic Torus P^1(R_4)
# ======================================================================

def _r4_mul(a, b, n):
    c0 = a[0]*b[0]
    c1 = a[0]*b[1] + a[1]*b[0]
    c2 = a[0]*b[2] + a[1]*b[1] + a[2]*b[0]
    c3 = a[0]*b[3] + a[1]*b[2] + a[2]*b[1] + a[3]*b[0]
    c4 = a[1]*b[3] + a[2]*b[2] + a[3]*b[1]
    c5 = a[2]*b[3] + a[3]*b[2]
    c6 = a[3]*b[3]
    r0 = (c0 - 5 * c4 - 10 * c6) % n
    r1 = (c1 - 5 * c5) % n
    r2 = (c2 + 2 * c4 - c6) % n
    r3 = (c3 + 2 * c5) % n
    return (r0, r1, r2, r3)


def _r4_add(a, b, n):
    return ((a[0] + b[0]) % n, (a[1] + b[1]) % n, (a[2] + b[2]) % n, (a[3] + b[3]) % n)


def _redei4_mul(P, Q, n):
    U1, V1 = P
    U2, V2 = Q
    u1u2 = _r4_mul(U1, U2, n)
    v1v2 = _r4_mul(V1, V2, n)
    tv = ((-5 * v1v2[3]) % n, v1v2[0], (v1v2[1] + 2 * v1v2[3]) % n, v1v2[2])
    U3 = _r4_add(u1u2, tv, n)
    V3 = _r4_add(_r4_mul(U1, V2, n), _r4_mul(V1, U2, n), n)
    return (U3, V3)


def _redei4_pow(P, k, n):
    res = ((1, 0, 0, 0), (0, 0, 0, 0))
    base = P
    while k > 0:
        if k & 1:
            res = _redei4_mul(res, base, n)
        base = _redei4_mul(base, base, n)
        k >>= 1
    return res


def _r4_norm_conj(v, n):
    a0 = (v[0] * v[0] - 5 * v[2] * v[2]) % n
    a1 = (2 * v[0] * v[2] + 2 * v[2] * v[2]) % n
    b0 = (v[1] * v[1] - 5 * v[3] * v[3]) % n
    b1 = (2 * v[1] * v[3] + 2 * v[3] * v[3]) % n
    d0 = (a0 + 5 * b1) % n
    d1 = (a1 - b0 - 2 * b1) % n
    norm_Z = (d0 * d0 + 2 * d0 * d1 + 5 * d1 * d1) % n
    v_neg = (v[0], (-v[1]) % n, v[2], (-v[3]) % n)
    d_bar = ((d0 + 2 * d1) % n, 0, (-d1) % n, 0)
    v_adj = _r4_mul(v_neg, d_bar, n)
    return norm_Z, v_adj


def lock03_generate(K_bound=1 << 11, B=1 << 13, n_small=32, seed=None, verbose=True):
    if seed is not None:
        random.seed(seed)
    t0 = time.time()
    pool = [l for l in primes_upto(B) if l > (1 << 11) and l % 8 == 1]
    M_full = math.prod([l for l in primes_upto(B) if l % 8 == 1])

    while True:
        ls = random.sample(pool, n_small)
        L_smooth = math.prod(ls)
        if not (390 <= L_smooth.bit_length() <= 465):
            continue
        roots = []
        for l in ls:
            s = sqrt_mod(l - 1, l)
            r = sqrt_mod(s, l)
            if r is None:
                r = sqrt_mod(l - s, l)
            assert pow(r, 4, l) == l - 1
            roots.append(r)
        r_all, M_all = _crt_combine(roots + [7], ls + [20])
        lo_p = 1 << 511
        k0 = (lo_p - r_all) // M_all
        p = None
        for k in range(k0, k0 + 250000):
            cand = r_all + k * M_all
            if cand.bit_length() == 512 and is_prime(cand):
                p = cand
                break
        if p is None:
            continue
        Phi8 = pow(p, 4) + 1
        G = math.gcd(Phi8, M_full)
        C8 = Phi8 // G
        break

    while True:
        q = random.getrandbits(512) | (1 << 511) | 1
        if q != p and is_prime(q):
            break
    N = p * q
    e0 = N % Phi8

    while True:
        d1 = random.randrange(3, K_bound)
        if not is_prime(d1):
            continue
        d2 = random.randrange(3, K_bound)
        if d2 == d1 or not is_prime(d2):
            continue
        if math.gcd(d2 + C8, Phi8) != 1:
            continue
        e = (d1 * e0 + C8) * pow(d2 + C8, -1, Phi8) % Phi8
        if e > 1 and math.gcd(e, (p - 1) * (q - 1)) == 1:
            break

    assert (d2 * M_full * e - d1 * M_full * N) % Phi8 == 0
    if verbose:
        print("  [Lock 03 KeyGen] %.2fs | p=%db q=%db N=%db | Phi8=%db | d1=%d d2=%d" %
              (time.time() - t0, p.bit_length(), q.bit_length(), N.bit_length(),
               Phi8.bit_length(), d1, d2))
    pub = {"N": N, "e": e, "K_bound": K_bound, "B": B}
    sk = {"p": p, "q": q, "d1": d1, "d2": d2, "Phi8": Phi8, "C8": C8}
    return pub, sk


def lock03_solve(pub, verbose=True):
    N = int(pub["N"])
    e = int(pub["e"])
    K_bound = int(pub.get("K_bound", 1 << 11))
    B = int(pub.get("B", 1 << 13))
    t0 = time.time()

    M = math.prod([l for l in primes_upto(B) if l % 8 == 1])
    P0 = ((2, 1, 0, 0), (1, 0, 0, 0))

    try:
        Q_L = _redei4_pow(P0, M * e, N)
        Q_R = _redei4_pow(P0, M * N, N)

        pts_L, cur = [], ((1, 0, 0, 0), (0, 0, 0, 0))
        for d2 in range(1, K_bound):
            cur = _redei4_mul(cur, Q_L, N)
            if is_prime(d2):
                pts_L.append(cur)

        pts_R, cur = [], ((1, 0, 0, 0), (0, 0, 0, 0))
        for d1 in range(1, K_bound):
            cur = _redei4_mul(cur, Q_R, N)
            if is_prime(d1):
                pts_R.append(cur)

        all_pts = pts_L + pts_R
        norms, adjs = [], []
        for _, V in all_pts:
            nm, adj = _r4_norm_conj(V, N)
            norms.append(nm)
            adjs.append(adj)
        inv_norms = _batch_inv_mod_n(norms, N)

        scalars = []
        for (U, _), adj, inv_nm in zip(all_pts, adjs, inv_norms):
            prod0 = _r4_mul(U, adj, N)[0]
            scalars.append(prod0 * inv_nm % N)

        kL = len(pts_L)
        lhs, rhs = scalars[:kL], scalars[kL:]
        g = batch_poly_gcd(lhs, rhs, N)
        if g and 1 < g < N:
            if verbose:
                print("  [Lock 03 Solve]  %.2fs | Phi_8(p) octic torus collision hit (%dx%d)" %
                      (time.time() - t0, len(lhs), len(rhs)))
            return g, N // g
    except FactorFound as ff:
        g = math.gcd(ff.p, N)
        if 1 < g < N:
            return g, N // g
    return None


# ======================================================================
# LOCK 04: Non-Maximal Order Conductor f=2 CM Curve (D = -7, j = -3375)
# ======================================================================

def lock04_generate(K_bound=1 << 11, seed=None, verbose=True):
    if seed is not None:
        random.seed(seed)
    t0 = time.time()
    while True:
        u = random.getrandbits(255) + (1 << 255)
        v = random.getrandbits(253) + (1 << 253)
        p = u * u + 7 * v * v
        if p.bit_length() != 512 or not is_prime(p):
            continue
        u0 = 1
        w = (u0 ** 3 - 35 * u0 - 98) % p
        a_curve = (-35 * w * w) % p
        P0 = ((u0 * w) % p, (w * w) % p)
        if ec_mul(p + 1 - 2 * u, P0, a_curve, p) is None:
            M_p = p + 1 - 2 * u
            break
        elif ec_mul(p + 1 + 2 * u, P0, a_curve, p) is None:
            M_p = p + 1 + 2 * u
            break

    while True:
        d1 = random.randrange(3, K_bound)
        if not is_prime(d1):
            continue
        d2 = random.randrange(3, K_bound)
        if d2 == d1 or not is_prime(d2):
            continue
        if math.gcd(d2 * p, M_p) != 1:
            continue
        inv_d2p = pow(d2 * p, -1, M_p)
        r_q = (d1 + 2 * d2) * inv_d2p % M_p
        q = None
        for k in range(1, 5000):
            cand = r_q + k * M_p
            if cand != p and is_prime(cand):
                q = cand
                break
        if q is not None:
            break

    N = p * q
    assert (d2 * (N * N - 4) - d1 * (N + 2)) % M_p == 0
    if verbose:
        print("  [Lock 04 KeyGen] %.2fs | p=%db q=%db M_p=%db | j=-3375 (D=-7) | d1=%d d2=%d" %
              (time.time() - t0, p.bit_length(), q.bit_length(), M_p.bit_length(), d1, d2))
    pub = {"N": N, "e": 65537, "K_bound": K_bound}
    sk = {"p": p, "q": q, "M_p": M_p, "d1": d1, "d2": d2}
    return pub, sk


def lock04_solve(pub, verbose=True):
    N = int(pub["N"])
    K_bound = int(pub.get("K_bound", 1 << 11))
    t0 = time.time()
    scalar_L = N * N - 4
    scalar_R = N + 2

    for u0 in range(1, 6):
        w = (u0 ** 3 - 35 * u0 - 98) % N
        if w == 0 or math.gcd(w, N) != 1:
            continue
        a_curve = (-35 * w * w) % N
        x0 = (u0 * w) % N
        y0 = (w * w) % N
        P0 = (x0, y0)
        try:
            Q_L = ec_mul(scalar_L, P0, a_curve, N)
            Q_R = ec_mul(scalar_R, P0, a_curve, N)
            if Q_L is None or Q_R is None:
                continue
            lhs, cur = [], None
            for d2 in range(1, K_bound):
                cur = ec_add(cur, Q_L, a_curve, N)
                if cur is None:
                    break
                if is_prime(d2):
                    lhs.append(cur[0])
            rhs, cur = [], None
            for d1 in range(1, K_bound):
                cur = ec_add(cur, Q_R, a_curve, N)
                if cur is None:
                    break
                if is_prime(d1):
                    rhs.append(cur[0])
            g = batch_poly_gcd(lhs, rhs, N)
            if g and 1 < g < N:
                if verbose:
                    print("  [Lock 04 Solve]  %.2fs | D=-7 (j=-3375) hit on u0=%d (%dx%d)" %
                          (time.time() - t0, u0, len(lhs), len(rhs)))
                return g, N // g
        except FactorFound as ff:
            g = math.gcd(ff.p, N)
            if 1 < g < N:
                return g, N // g
        except ZeroDivisionError:
            continue
    return None


# ======================================================================
# LOCK 05: Genus-2 Hyperelliptic Curve Jacobian Jac(C)(Z/NZ)
# ======================================================================

def _p_add(A, B, n):
    L = max(len(A), len(B))
    return _poly_trim([((A[i] if i < len(A) else 0) + (B[i] if i < len(B) else 0)) % n
                       for i in range(L)])


def _p_sub(A, B, n):
    L = max(len(A), len(B))
    return _poly_trim([((A[i] if i < len(A) else 0) - (B[i] if i < len(B) else 0)) % n
                       for i in range(L)])


def _p_mul_small(A, B, n):
    if not A or not B:
        return []
    res = [0] * (len(A) + len(B) - 1)
    for i, a in enumerate(A):
        if a:
            for j, b in enumerate(B):
                res[i + j] = (res[i + j] + a * b) % n
    return _poly_trim(res)


def _p_extgcd(A, B, n):
    old_r, r = _poly_trim(A), _poly_trim(B)
    old_s, s = [1], []
    old_t, t = [], [1]
    while r:
        q, rem = _poly_divmod_small(old_r, r, n)
        old_r, r = r, rem
        old_s, s = s, _p_sub(old_s, _p_mul_small(q, s, n), n)
        old_t, t = t, _p_sub(old_t, _p_mul_small(q, t, n), n)
    if not old_r:
        return [], [], []
    inv_lc = inv_mod_n(old_r[-1], n)
    d = [c * inv_lc % n for c in old_r]
    s_out = [c * inv_lc % n for c in old_s]
    t_out = [c * inv_lc % n for c in old_t]
    return d, s_out, t_out


def cantor_add(D1, D2, f_curve, n):
    u1, v1 = D1
    u2, v2 = D2
    if len(u1) == 1:
        return D2
    if len(u2) == 1:
        return D1
    d1, e1, e2 = _p_extgcd(u1, u2, n)
    v_sum = _p_add(v1, v2, n)
    if not v_sum:
        d, c1, c2 = d1, [1], []
    else:
        d, c1, c2 = _p_extgcd(d1, v_sum, n)
    s1 = _p_mul_small(c1, e1, n)
    s2 = _p_mul_small(c1, e2, n)
    s3 = c2
    d_sq = _p_mul_small(d, d, n)
    u_prod = _p_mul_small(u1, u2, n)
    u, _ = _poly_divmod_small(u_prod, d_sq, n)
    t1 = _p_mul_small(_p_mul_small(s1, u1, n), v2, n)
    t2 = _p_mul_small(_p_mul_small(s2, u2, n), v1, n)
    t3 = _p_mul_small(s3, _p_add(_p_mul_small(v1, v2, n), f_curve, n), n)
    v_num = _p_add(_p_add(t1, t2, n), t3, n)
    v_quo, _ = _poly_divmod_small(v_num, d, n)
    _, v = _poly_divmod_small(v_quo, u, n)
    while len(u) - 1 > 2:
        f_minus_v2 = _p_sub(f_curve, _p_mul_small(v, v, n), n)
        u_next, _ = _poly_divmod_small(f_minus_v2, u, n)
        if not u_next:
            return ([1], [])
        inv_lc = inv_mod_n(u_next[-1], n)
        u = [c * inv_lc % n for c in u_next]
        neg_v = [(-c) % n for c in v]
        _, v = _poly_divmod_small(neg_v, u, n)
    inv_lc = inv_mod_n(u[-1], n)
    u = [c * inv_lc % n for c in u]
    return (u, v)


def cantor_mul(k, D, f_curve, n):
    res = ([1], [])
    base = D
    while k > 0:
        if k & 1:
            res = cantor_add(res, base, f_curve, n)
        base = cantor_add(base, base, f_curve, n)
        k >>= 1
    return res


def lock05_generate(K_bound=1 << 11, B=1 << 13, n_small=34, seed=None, verbose=True):
    if seed is not None:
        random.seed(seed)
    t0 = time.time()
    pool = [l for l in primes_upto(B) if l > (1 << 11) and l % 4 == 1 and l != 5]
    M_full = math.prod([l for l in primes_upto(B) if l % 4 == 1])

    while True:
        ls = random.sample(pool, n_small)
        L_smooth = math.prod(ls)
        if not (425 <= L_smooth.bit_length() <= 470):
            continue
        roots = [sqrt_mod(l - 1, l) for l in ls]
        r_all, M_all = _crt_combine(roots + [7], ls + [20])
        lo_p = 1 << 511
        k0 = (lo_p - r_all) // M_all
        p = None
        for k in range(k0, k0 + 250000):
            cand = r_all + k * M_all
            if cand.bit_length() == 512 and is_prime(cand):
                p = cand
                break
        if p is None:
            continue
        J_ord = p * p + 1
        G = math.gcd(J_ord, M_full)
        C_jac = J_ord // G
        if C_jac.bit_length() >= 540:
            break

    while True:
        q = random.getrandbits(512) | (1 << 511) | 1
        if q != p and is_prime(q):
            break
    N = p * q
    e0 = N % J_ord

    while True:
        d1 = random.randrange(3, K_bound)
        if not is_prime(d1):
            continue
        d2 = random.randrange(3, K_bound)
        if d2 == d1 or not is_prime(d2):
            continue
        if math.gcd(d2 + C_jac, J_ord) != 1:
            continue
        e = (d1 * e0 + C_jac) * pow(d2 + C_jac, -1, J_ord) % J_ord
        if e > 1 and math.gcd(e, (p - 1) * (q - 1)) == 1:
            break

    if verbose:
        print("  [Lock 05 KeyGen] %.2fs | p=%db q=%db N=%db | #Jac=p^2+1 | d1=%d d2=%d" %
              (time.time() - t0, p.bit_length(), q.bit_length(), N.bit_length(), d1, d2))
    pub = {"N": N, "e": e, "K_bound": K_bound, "B": B}
    sk = {"p": p, "q": q, "d1": d1, "d2": d2, "J_ord": J_ord, "C_jac": C_jac}
    return pub, sk


def lock05_solve(pub, verbose=True):
    N = int(pub["N"])
    e = int(pub["e"])
    K_bound = int(pub.get("K_bound", 1 << 11))
    B = int(pub.get("B", 1 << 13))
    t0 = time.time()

    M = math.prod([l for l in primes_upto(B) if l % 4 == 1])
    f_curve = [8, 0, 0, 0, 0, 1]
    D0 = ([(-1) % N, 1], [3])

    try:
        D_L = cantor_mul(M * e, D0, f_curve, N)
        D_R = cantor_mul(M * N, D0, f_curve, N)

        lhs, cur = [], ([1], [])
        for d2 in range(1, K_bound):
            cur = cantor_add(cur, D_L, f_curve, N)
            if is_prime(d2):
                lhs.append(cur[0][0] if cur[0] else 0)

        rhs, cur = [], ([1], [])
        for d1 in range(1, K_bound):
            cur = cantor_add(cur, D_R, f_curve, N)
            if is_prime(d1):
                rhs.append(cur[0][0] if cur[0] else 0)

        g = batch_poly_gcd(lhs, rhs, N)
        if g and 1 < g < N:
            if verbose:
                print("  [Lock 05 Solve]  %.2fs | Genus-2 Cantor Jacobian collision hit (%dx%d)" %
                      (time.time() - t0, len(lhs), len(rhs)))
            return g, N // g
    except FactorFound as ff:
        g = math.gcd(ff.p, N)
        if 1 < g < N:
            if verbose:
                print("  [Lock 05 Solve]  %.2fs | Genus-2 Cantor division captured factor directly" %
                      (time.time() - t0))
            return g, N // g
    return None
